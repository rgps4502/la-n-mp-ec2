#!/bin/bash
docker run -p 80:80 --name devops -d 129729052534.dkr.ecr.ap-northeast-1.amazonaws.com/dc103_repo_dev:latest
